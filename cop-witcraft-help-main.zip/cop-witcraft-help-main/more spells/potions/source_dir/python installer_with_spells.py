Http://www.github.com/installer.py/cop-witcraft-hulp.
