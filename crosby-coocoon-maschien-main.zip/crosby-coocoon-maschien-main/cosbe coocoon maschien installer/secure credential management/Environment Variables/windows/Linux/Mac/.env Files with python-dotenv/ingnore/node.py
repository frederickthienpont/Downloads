pip install python-dotenv

SENDER_EMAIL=youremail@example.com
EMAIL_PASSWORD=your_password

from dotenv import load_dotenv
import os

# Load environment variables from the .env file
load_dotenv()

# Retrieve sensitive information from environment variables
sender_email = os.getenv("SENDER_EMAIL")
email_password = os.getenv("EMAIL_PASSWORD")

# Check if the credentials are loaded properly
if sender_email and email_password:
    print("Credentials loaded successfully.")
else:
    print("Error: Could not load credentials.")

.env
