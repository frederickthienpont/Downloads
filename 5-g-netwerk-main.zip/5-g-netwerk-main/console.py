import sys
from datetime import datetime

# In-memory database
klanten = {}

# 5G abonnementen
abonnementen_5g = {
    "starter": {"snelheid": "300 Mbps", "datalimiet": "100 GB", "prijs": 30},
    "pro": {"snelheid": "800 Mbps", "datalimiet": "500 GB", "prijs": 50},
    "ultra": {"snelheid": "1.5 Gbps", "datalimiet": "Onbeperkt", "prijs": 75}
}

def voeg_klant_toe():
    klant_id = input("SIM ID / Klant-ID: ")
    naam = input("Naam: ")
    regio = input("Regio (bv. Amsterdam): ")
    klanten[klant_id] = {
        "naam": naam,
        "regio": regio,
        "abonnement": None,
        "verbruik_gb": 0,
        "aangemaakt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    print(f"Klant '{naam}' in regio '{regio}' toegevoegd.\n")

def kies_abonnement():
    klant_id = input("SIM ID / Klant-ID: ")
    if klant_id not in klanten:
        print("Klant niet gevonden.\n")
        return

    print("Beschikbare 5G-abonnementen:")
    for naam, ab in abonnementen_5g.items():
        print(f"- {naam.capitalize()} | {ab['snel]()
