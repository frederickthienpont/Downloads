def process_payment(contract_id, amount, currency="EUR"):
    # Simulatie
    print(f"Verwerking betaling van {amount} {currency} voor contract {contract_id}")
    return True
