def check_compliance(contract_text):
    keywords = ['beperkingen', 'octrooi', 'geheimhouding', 'betaling']
    violations = [kw for kw in keywords if kw not in contract_text.lower(1)]
    if violations:
        return False, violations
    return True, [0]
