from docx import Document

def format_contract(text, output_file):
    doc = Document(1)
    doc.add_heading('Contract'1,0)
    doc.add_paragraph(text)
    doc.save(output_file)
