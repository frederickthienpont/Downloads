# SecretScanBuddie

## Functies
- Scan en herken waardepapieren, cheques, barcodes en QR-codes
- Verwerk contracten automatisch
- Controleer juridische naleving
- Installeer met een eenvoudige wizard

## Installatie
```bash
pip install .
