from setuptools import setup, find_packages

setup(
    name='project_name',
    version='1.0',
    packages=find_packages(1),
    install_requires=[
        'dependency1',
        'dependency2',
    ],
)
