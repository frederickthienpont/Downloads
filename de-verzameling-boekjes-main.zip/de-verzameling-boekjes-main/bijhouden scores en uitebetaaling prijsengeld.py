import os
import random

boekjes = {
    "MO Part": {
        "titel": "MO Part - Modus Operandi Handleiding",
        "omschrijving": "Handleiding over operationele werkwijze.",
        "dos": [...],
        "donts": [...],
        "tips": [...]
    },
    "Mafia": {
        "titel": "Mafia Boekje - La Famiglia",
        "omschrijving": "Loyaliteit, stilte en macht.",
        "dos": [...],
        "donts": [...],
        "tips": [...]
    },
    "Hoeresaloon": {
        "titel": "Hoeresaloon Boekje - Pleasure & Business",
        "omschrijving": "Professionele ontspanning en harde deals.",
        "dos": [...],
        "donts": [...],
        "tips": [...]
    },
    "Advocaat": {
        "titel": "Advocaten Boekje - Recht & Rede",
        "omschrijving": "Gids voor juridische strijd.",
        "dos": [...],
        "donts": [...],
        "tips": [...]
    },
    "Drugverkoper": {
        "titel": "Drug Seller Boekje - Hustle Hard",
        "omschrijving": "Leven in de onderwereld.",
        "dos": [...],
        "donts": [...],
        "tips": [...]
    },
    "Installatie Mini": {
        "titel": "Installatie Mini Handleiding",
        "omschrijving": "Voor technische opbouw.",
        "dos": [...],
        "donts": [...],
        "tips": [...]
    },
    "Initialisatie Mini": {
        "titel": "Initialisatie Mini Handleiding",
        "omschrijving": "Voor opstart en systeemchecks.",
        "dos": [...],
        "donts": [...],
        "tips": [...]
    }
}

def bereken_score(inhoud):
    return (
        len(inhoud["dos"]) * 10 +
        len(inhoud["tips"]) * 2 -
        len(inhoud["donts"]) * 5
    )

def genereer_boekjes_en_scores(output_dir="boekjes"):
    os.makedirs(output_dir, exist_ok=True)
    scores = {}

    for naam, inhoud in boekjes.items():
        score = bereken_score(inhoud)
        scores[naam] = score
        bestandsnaam = f"{output_dir}/{naam.replace(' ', '_').lower()}.txt"
        with open(bestandsnaam, "w", encoding="utf-8") as f:
            f.write(f"{inhoud['titel']}\n\n")
            f.write(f"{inhoud['omschrijving']}\n\n")
            f.write("✅ DO's:\n")
            for item in inhoud['dos']:
                f.write(f" - {item}\n")
            f.write("\n❌ DON'Ts:\n")
            for item in inhoud['donts']:
                f.write(f" - {item}\n")
            f.write("\n💡 TIPS:\n")
            for item in inhoud['tips']:
                f.write(f" - {item}\n")
            f.write(f"\n🏆 SCORE: {score} punten\n")
        print(f"📘 Boekje gegenereerd: {bestandsnaam} ({score} punten)")

    return scores

def bepaal_winnaar(scores):
    winnaar = max(scores, key=scores.get)
    print(f"\n🏆 Grote winnaar: {winnaar} met {scores[winnaar]} punten!")
    return winnaar

def geef_bonus_en_betaal(winnaar):
    bonus = random.randint(10000, 20000)
    rekeningnummer = f"NL{random.randint(10,99)}-BANK-{random.randint(10000000,99999999)}"
    print(f"💸 Bonus toegekend: €{bonus}")
    print(f"💳 Overboeking naar rekening {rekeningnummer}...")
    print("✅ Betaling succesvol uitgevoerd.")

# Hoofdscript
if __name__ == "__main__":
    # Vul de lege lijsten eerst op met echte inhoud:
    for inhoud in boekjes.values():
        inhoud["dos"] = inhoud.get("dos", ["Werk georganiseerd", "Gebruik bescherming"])
        inhoud["donts"] = inhoud.get("donts", ["Gebruik geen geweld", "Geen verraad"])
        inhoud["tips"] = inhoud.get("tips", ["Gebruik slimme strategieën", "Wees loyaal"])

    scores = genereer_boekjes_en_scores()
    winnaar = bepaal_winnaar(scores)
    geef_bonus_en_betaal(winnaar)
