from typing import List
from datetime import datetime
import json
import os

# Bestanden voor facturen en bestellingen
FACTUUR_FILE = "data/facturen.json"
BESTELLING_FILE = "data/bestellingen.json"

class Factuur:
    def __init__(self, id, bestelling_id, leverancier_id, totaalbedrag, betalingsstatus, factuurdatum, betaaldatum=None):
        self.id = id
        self.bestelling_id = bestelling_id
        self.leverancier_id = leverancier_id
        self.totaalbedrag = totaalbedrag
        self.betalingstatus = betalingsstatus
        self.factuurdatum = factuurdatum
        self.betaaldatum = betaaldatum

class Bestelling:
    def __init__(self, id, leverancier_id, totaalbedrag, bestel_datum):
        self.id = id
        self.leverancier_id = leverancier_id
        self.totaalbedrag = totaalbedrag
        self.bestel_datum = bestel_datum

def laad_facturen() -> List[Factuur]:
    if not os.path.exists(FACTUUR_FILE):
        return []
    with open(FACTUUR_FILE, "r") as f:
        data = json.load(f)
    return [Factuur(**f) for f in data]

def laad_bestellingen() -> List[Bestelling]:
    if not os.path.exists(BESTELLING_FILE):
        return []
    with open(BESTELLING_FILE, "r") as f:
        data = json.load(f)
    return [Bestelling(**b) for b in data]

def omzetrapport(start_date: datetime, end_date: datetime):
    facturen = laad_facturen()
    omzet = 0
    for factuur in facturen:
        if factuur.betalingstatus == "Betaald" and start_date <= factuur.betaaldatum <= end_date:
            omzet += factuur.totaalbedrag
    print(f"📈 Totale omzet tussen {start_date.strftime('%Y-%m-%d')} en {end_date.strftime('%Y-%m-%d')}: €{omzet:.2f}")

def kostenrapport(start_date: datetime, end_date: datetime):
    bestellingen = laad_bestellingen()
    kosten_per_leverancier = {}
    for bestelling in bestellingen:
        if start_date <= bestelling.bestel_datum <= end_date:
            if bestelling.leverancier_id not in kosten_per_leverancier:
                kosten_per_leverancier[bestelling.leverancier_id] = 0
            kosten_per_leverancier[bestelling.leverancier_id] += bestelling.totaalbedrag
    print(f"💰 Kosten per leverancier tussen {start_date.strftime('%Y-%m-%d')} en {end_date.strftime('%Y-%m-%d')}:")
    for leverancier_id, kosten in kosten_per_leverancier.items():
        print(f"  Leverancier {leverancier_id}: €{kosten:.2f}")

def winstrapport(start_date: datetime, end_date: datetime):
    omzetrapport(start_date, end_date)
    kostenrapport(start_date, end_date)
    facturen = laad_facturen()
    omzet = 0
    for factuur in facturen:
        if factuur.betalingstatus == "Betaald" and start_date <= factuur.betaaldatum <= end_date:
            omzet += factuur.totaalbedrag
    bestellingen = laad_bestellingen()
    kosten = 0
    for bestelling in bestellingen:
        if start_date <= bestelling.bestel_datum <= end_date:
            kosten += bestelling.totaalbedrag
    winst = omzet - kosten
    print(f"💸 Totale winst tussen {start_date.strftime('%Y-%m-%d')} en {end_date.strftime('%Y-%m-%d')}: €{winst:.2f}")

def info():
    return "Rapportages-module actief – Omzet-, kosten- en winstrapporten genereren klaar"
