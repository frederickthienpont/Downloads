from flask import Flask, render_template_string
import random

app = Flask(__name__)

boekjes = {
    "MO Part": {"dos": [...], "donts": [...], "tips": [...], "omschrijving": "Handleiding voor operaties."},
    "Mafia": {"dos": [...], "donts": [...], "tips": [...], "omschrijving": "La Famiglia lifestyle."},
    "Hoeresaloon": {"dos": [...], "donts": [...], "tips": [...], "omschrijving": "Pleasure & rules."},
    "Advocaat": {"dos": [...], "donts": [...], "tips": [...], "omschrijving": "Juridisch meesterschap."},
    "Drugverkoper": {"dos": [...], "donts": [...], "tips": [...], "omschrijving": "Deal slim en veilig."},
    "Installatie Mini": {"dos": [...], "donts": [...], "tips": [...], "omschrijving": "Snelle setup gids."},
    "Initialisatie Mini": {"dos": [...], "donts": [...], "tips": [...], "omschrijving": "Opstart en checks."}
}

# Voorbeeldinhoud toevoegen als ze leeg zijn
for boekje in boekjes.values():
    boekje["dos"] = boekje.get("dos", ["Doe A", "Doe B", "Doe C"])
    boekje["donts"] = boekje.get("donts", ["Doe dit niet", "Doe dat niet"])
    boekje["tips"] = boekje.get("tips", ["Handige tip", "Nog een tip"])

# Score berekening
def bereken_score(data):
    return len(data["dos"]) * 10 + len(data["tips"]) * 2 - len(data["donts"]) * 5

@app.route("/")
def homepage():
    scores = {}
    for naam, data in boekjes.items():
        score = bereken_score(data)
        scores[naam] = {
            "score": score,
            "omschrijving": data["omschrijving"],
            "dos": data["dos"],
            "donts": data["donts"],
            "tips": data["tips"]
        }

    winnaar = max(scores, key=lambda x: scores[x]['score'])
    bonus = random.randint(10000, 20000)
    rekening = f"NL{random.randint(10,99)}-BANK-{random.randint(10000000,99999999)}"

    return render_template_string("""
    <html>
    <head>
        <title>Boekjes Overzicht</title>
        <style>
            body { font-family: Arial; background: #121212; color: #eee; padding: 20px; }
            .boekje { margin-bottom: 40px; border: 1px solid #333; padding: 20px; border-radius: 8px; background: #1e1e1e; }
            h2 { color: #ffd700; }
            .winnaar { color: lime; font-size: 1.4em; }
        </style>
    </head>
    <body>
        <h1>📘 Boekjes Dashboard</h1>
        {% for naam, data in scores.items() %}
            <div class="boekje">
                <h2>{{ naam }}</h2>
                <p><strong>Omschrijving:</strong> {{ data.omschrijving }}</p>
                <p><strong>✅ DO's:</strong> {{ data.dos | join(', ') }}</p>
                <p><strong>❌ DON'Ts:</strong> {{ data.donts | join(', ') }}</p>
                <p><strong>💡 Tips:</strong> {{ data.tips | join(', ') }}</p>
                <p><strong>🏆 Score:</strong> {{ data.score }} punten</p>
            </div>
        {% endfor %}
        <hr>
        <h2 class="winnaar">🥇 Grote winnaar: {{ winnaar }} met {{ scores[winnaar]['score'] }} punten</h2>
        <p>💰 Bonus uitgekeerd: €{{ bonus }}</p>
        <p>💳 Betaling overgemaakt naar: <strong>{{ rekening }}</strong></p>
    </body>
    </html>
    """, scores=scores, winnaar=winnaar, bonus=bonus, rekening=rekening)

if __name__ == "__main__":
    app.run(debug=True)
