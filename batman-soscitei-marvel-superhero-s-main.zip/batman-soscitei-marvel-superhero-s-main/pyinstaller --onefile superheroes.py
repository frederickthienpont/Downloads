[Setup]
AppName=Superhero Info
AppVersion=1.0
DefaultDirName={pf}\SuperheroInfo
DefaultGroupName=Superhero Info
OutputDir=.
OutputBaseFilename=SuperheroInfoInstaller

[Files]
Source: "dist\superheroes.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Superhero Info"; Filename: "{app}\superheroes.exe"

[Run]
Filename: "{app}\superheroes.exe"; Description: "Launch Superhero Info"; Flags: nowait postinstall skipifsilent
