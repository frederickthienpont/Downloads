class StaatRekening:
    def __init__(self):
        self.saldo = 0.0
        self.belastingvoorheffing = 0.0
        self.leningen_inkomend = []
        self.leningen_uitgaand = []
        self.transacties = []

    def stortinkomen(self, bedrag, belastingtarief=0.25):
        """Voert belastingvoorheffing af en stort netto op rekening"""
        belasting = bedrag * belastingtarief
        netto = bedrag - belasting
        self.belastingvoorheffing += belasting
        self.saldo += netto
        self.transacties.append(f"Inkomen: {bedrag:.2f} (Netto: {netto:.2f}, Belasting: {belasting:.2f})")

    def betaalbelasting(self):
        """Betaalt de opgebouwde belastingvoorheffing"""
        self.transacties.append(f"Belasting betaald: {self.belastingvoorheffing:.2f}")
        self.saldo -= self.belastingvoorheffing
        self.belastingvoorheffing = 0.0

    def neem_lening_in(self, bedrag, beschrijving=""):
        """Registreert een inkomende lening (krediet)"""
        self.leningen_inkomend.append((bedrag, beschrijving))
        self.saldo += bedrag
        self.transacties.append(f"Inkomende lening: {bedrag:.2f} ({beschrijving})")

    def geef_lening_uit(self, bedrag, beschrijving=""):
        """Registreert een uitgaande lening (geld uitgeleend)"""
        self.leningen_uitgaand.append((bedrag, beschrijving))
        self.saldo -= bedrag
        self.transacties.append(f"Uitgaande lening: {bedrag:.2f} ({beschrijving})")

    def overzicht(self):
        """Toont de staat van de rekening"""
        print("\n=== STAATREKENING OVERZICHT ===")
        print(f"Huidig saldo: €{self.saldo:.2f}")
        print(f"Openstaande belastingvoorheffing: €{self.belastingvoorheffing:.2f}")
        print("\nInkomende leningen:")
        for bedrag, beschrijving in self.leningen_inkomend:
            print(f"  + €{bedrag:.2f} ({beschrijving})")
        print("\nUitgaande leningen:")
        for bedrag, beschrijving in self.leningen_uitgaand:
            print(f"  - €{bedrag:.2f} ({beschrijving})")
        print("\nTransactiegeschiedenis:")
        for t in self.transacties:
            print(f"  - {t}")
        print("================================\n")


# --- Voorbeeldgebruik ---
if __name__ == "__main__":
    sr = StaatRekening()
    
    sr.stortinkomen(5000.00)  # 25% belasting
    sr.neem_lening_in(2000.00, "Investeerder X")
    sr.geef_lening_uit(1000.00, "Lening aan vriend Y")
    sr.betaalbelasting()
    sr.overzicht()
