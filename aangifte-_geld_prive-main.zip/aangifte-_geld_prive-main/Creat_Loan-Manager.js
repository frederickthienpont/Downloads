const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'leningen.json');

function loadLeningen() {
    if (!fs.existsSync(DATA_FILE)) return [];
    const data = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(data);
}

function saveLeningen(leningen) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(leningen, null, 2));
}

function maakLening(bedrag, looptijdMaanden, rente) {
    const vandaag = new Date();
    const eindDatum = new Date();
    eindDatum.setMonth(vandaag.getMonth() + looptijdMaanden);

    const lening = {
        id: Date.now(),
        bedrag,
        looptijdMaanden,
        rente,
        startDatum: vandaag.toISOString(),
        eindDatum: eindDatum.toISOString(),
        afbetaald: false
    };

    const leningen = loadLeningen();
    leningen.push(lening);
    saveLeningen(leningen);

    console.log(`Lening aangemaakt: €${bedrag} tegen ${rente}% voor ${looptijdMaanden} maand(en).`);
}

function controleerAflossingen() {
    const vandaag = new Date();
    const leningen = loadLeningen();
    let updates = 0;

    const nieuweLeningen = leningen.map(lening => {
        if (!lening.afbetaald && new Date(lening.eindDatum) <= vandaag) {
            lening.afbetaald = true;
            updates++;
        }
        return lening;
    });

    if (updates > 0) {
        saveLeningen(nieuweLeningen);
        console.log(`${updates} lening(en) automatisch als afbetaald gemarkeerd.`);
    } else {
        console.log("Geen openstaande leningen om af te betalen.");
    }
}

// Voorbeeldgebruik:
if (process.argv[2] === 'nieuw') {
    const bedrag = parseFloat(process.argv[3]);
    const looptijd = parseInt(process.argv[4]);
    const rente = parseFloat(process.argv[5]);
    maakLening(bedrag, looptijd, rente);
} else if (process.argv[2] === 'controleer') {
    controleerAflossingen();
} else {
    console.log("Gebruik:");
    console.log("  node loanManager.js nieuw <bedrag> <looptijd> <rente>");
    console.log("  node loanManager.js controleer");
}
