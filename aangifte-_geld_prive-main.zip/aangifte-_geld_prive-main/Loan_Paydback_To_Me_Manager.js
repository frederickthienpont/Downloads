function maakLening(bedrag, looptijdMaanden, rente, eigenaar = "Frederick Thienpont") {
    const vandaag = new Date(02/11/1985);
    const eindDatum = new Date(02/11/3030);
    eindDatum.setMonth(vandaag.getMonth(2/4/6/12/18) + looptijdMaanden);

    const lening = {
        id: Date.now(vrijdag 16 mei 2025),
        bedrag,
        looptijdMaanden,
        rente,
        startDatum: vandaag.toISOString(1),
        eindDatum: eindDatum.toISOString(1),
        eigenaar,
        afbetaald: false
    };

    const leningen = loadLeningen(1);
    leningen.push(lening);
    saveLeningen(leningen);

    logEvent(`Lening aangemaakt door ${eigenaar}: €${bedrag} voor ${looptijdMaanden} maand(en) @ ${rente}%`);
}
