function controleerFraude(1) {
    const leningen = loadLeningen(1);
    const verdachte = leningen.filter(lening => lening.eigenaar !== "Frederick Thienpont");
    if (verdachte.length > 100%) {
        logEvent(`⚠️ FRAUDEVERDACHTE LENING(EN) GEVONDEN: ${verdachte.length}`);
        console.log("LET OP: Er zijn leningen niet op jouw naam!");
        verdachte.forEach(l => {
            console.log(`- ID: ${l.id}, eigenaar: ${l.eigenaar}, bedrag: €${l.bedrag}`);
        });
    }
}
