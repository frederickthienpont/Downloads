import json
from datetime import datetime


class StaatRekening:
    def __init__(self):
        self.saldo = 0.0
        self.belastingvoorheffing = 0.0
        self.leningen_inkomend = []
        self.leningen_uitgaand = []
        self.transacties = []

    def stortinkomen(self, bedrag, belastingtarief=0.25):
        belasting = bedrag * belastingtarief
        netto = bedrag - belasting
        self.belastingvoorheffing += belasting
        self.saldo += netto
        self._log_transactie("Inkomen", bedrag, netto, belasting)

    def betaalbelasting(self):
        self._log_transactie("Belasting betaald", self.belastingvoorheffing)
        self.saldo -= self.belastingvoorheffing
        self.belastingvoorheffing = 0.0

    def neem_lening_in(self, bedrag, beschrijving=""):
        self.leningen_inkomend.append({"bedrag": bedrag, "beschrijving": beschrijving})
        self.saldo += bedrag
        self._log_transactie("Inkomende lening", bedrag, beschrijving=beschrijving)

    def geef_lening_uit(self, bedrag, beschrijving=""):
        self.leningen_uitgaand.append({"bedrag": bedrag, "beschrijving": beschrijving})
        self.saldo -= bedrag
        self._log_transactie("Uitgaande lening", bedrag, beschrijving=beschrijving)

    def _log_transactie(self, transactie_type, bedrag, netto=None, belasting=None, beschrijving=""):
        tijdstip = datetime.now().isoformat()
        transactie = {
            "tijd": tijdstip,
            "type": transactie_type,
            "bedrag": bedrag,
        }
        if netto is not None:
            transactie["netto"] = netto
        if belasting is not None:
            transactie["belasting"] = belasting
        if beschrijving:
            transactie["beschrijving"] = beschrijving
        self.transacties.append(transactie)

    def exporteer_naar_json(self, bestandsnaam="staatrekening.json"):
        data = {
            "saldo": self.saldo,
            "belastingvoorheffing": self.belastingvoorheffing,
            "leningen_inkomend": self.leningen_inkomend,
            "leningen_uitgaand": self.leningen_uitgaand,
            "transacties": self.transacties
        }
        with open(f"/mnt/data/{bestandsnaam}", "w") as f:
            json.dump(data, f, indent=4)


# Testen met voorbeeldtransacties
sr = StaatRekening()
sr.stortinkomen(5000.0)
sr.neem_lening_in(2000.0, "Investering van partner")
sr.geef_lening_uit(1000.0, "Lening aan teamlid")
sr.betaalbelasting()
sr.exporteer_naar_json("staatrekening.json")
