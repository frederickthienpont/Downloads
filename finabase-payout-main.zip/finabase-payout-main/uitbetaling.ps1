# Configuratie
$apiKey = "JOUW_API_SLEUTEL_HIER"
$apiUrl = "https://sandbox.finabase.io/api/v1/payments"  # Pas aan indien live omgeving

# Gebruikersinput
$ontvanger = Read-Host "Voer het walletadres of IBAN van de ontvanger in"
$bedrag = Read-Host "Voer het bedrag in (bijv. 100.00)"
$valuta = Read-Host "Valuta? (Bijv. EUR of BTC)"
$notitie = Read-Host "Opmerking bij uitbetaling (optioneel)"

# Tijdstempel
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

# Payload voorbereiden
$body = @{
    recipient = $ontvanger
    amount    = $bedrag
    currency  = $valuta
    note      = $notitie
} | ConvertTo-Json -Depth 3

# Headers
$headers = @{
    "Authorization" = "Bearer $apiKey"
    "Content-Type"  = "application/json"
}

# Aanvraag uitvoeren
try {
    $response = Invoke-RestMethod -Method POST -Uri $apiUrl -Headers $headers -Body $body
    Write-Host "`n✅ Uitbetaling verzonden! Transactie-ID: $($response.transaction_id)`n"

    # Logbestand bijwerken
    $logregel = "$timestamp | $bedrag $valuta naar $ontvanger | Transactie-ID: $($response.transaction_id)`n"
    Add-Content -Path "uitbetalingen.log" -Value $logregel
} catch {
    Write-Host "`n❌ Fout bij verzenden: $($_.Exception.Message)`n"
}
