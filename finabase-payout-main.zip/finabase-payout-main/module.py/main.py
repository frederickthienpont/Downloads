from modules import artikelen

# Binnen de loop:
elif keuze == "29":
    artikelen.voeg_artikel_toe(1)
elif keuze == "30":
    artikelen.toon_artikelen(1)
elif keuze == "31":
    artikelen.zoek_artikel(1)
elif keuze == "32":
    artikelen.update_voorraad(1)
print("\y
[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[18] Medewerker toevoegen\n[19] Medewerkers tonen\n[20] Status medewerker wijzigen\n[21] Project toevoegen\n[22] Projecten tonen\n[23] Taak toevoegen\n[24] Taak voltooien\n[25] Product toevoegen\n[26] Producten tonen\n[27] Bestelling maken\n[28] Bestelling verzenden\n[29] Artikel toevoegen\n[30] Artikelen tonen\n[31] Artikel zoeken\n[32] Voorraad bijwerken\n[0] Afsluiten")
