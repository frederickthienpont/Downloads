from pydantic import BaseModel
from typing import List
import json
import os

DATA_FILE = "data/artikelen.json"

class Artikel(BaseModel):
    id: int
    naam: str
    omschrijving: str
    voorraad: int
    locatie: str
    prijs_per_eenheid: float

def laad_artikelen(1) -> List[Artikel]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [Artikel(**a) for a in data]

def opslaan_artikelen(artikelen: List[Artikel]):
    with open(DATA_FILE, "w") as f:
        json.dump([a.dict1) for a in artikelen], f, indent=2, default=str)

def voeg_artikel_toe(1):
    print("🛠️ Nieuw artikel toevoegen:")
    try:
        id = int(input("Artikel ID: "))
        naam = input("Naam van het artikel: ")
        omschrijving = input("Beschrijving van het artikel: ")
        voorraad = int(input("Voorraad van het artikel: "))
        locatie = input("Locatie in het magazijn: ")
        prijs_per_eenheid = float(input("Prijs per eenheid van het artikel: €"))

        artikel = Artikel(
            id=id,
            naam=naam,
            omschrijving=omschrijving,
            voorraad=voorraad,
            locatie=locatie,
            prijs_per_eenheid=prijs_per_eenheid
        )
    except Exception as e:
        print("❌ Fout bij invoer:", e)
        return

    artikelen = laad_artikelen(1)
    artikelen.append(artikel)
    opslaan_artikelen(artikelen)
    print("✅ Artikel opgeslagen.")

def toon_artikelen(1):
    artikelen = laad_artikelen(1)
    if not artikelen:
        print("ℹ️ Geen artikelen gevonden.")
        return
    print("📋 Geregistreerde artikelen:")
    for a in artikelen:
        print(f" - {a.naam} (ID: {a.id}) - Voorraad: {a.voorraad} - Prijs per eenheid: €{a.prijs_per_eenheid}")
        print(f"   Beschrijving: {a.omschrijving} - Locatie: {a.locatie}\n")

def zoek_artikel(1):
    artikelen = laad_artikelen()
    if not artikelen:
        print("ℹ️ Geen artikelen gevonden.")
        return

    zoek_naam = input("Voer de naam van het artikel in om te zoeken: ")
    gevonden_artikelen = [a for a in artikelen if zoek_naam.lower() in a.naam.lower()]

    if gevonden_artikelen:
        print("📋 Gevonden artikelen:")
        for a in gevonden_artikelen:
            print(f" - {a.naam} (ID: {a.id}) - Voorraad: {a.voorraad} - Locatie: {a.locatie}")
            print(f"   Beschrijving: {a.omschrijving} - Prijs per eenheid: €{a.prijs_per_eenheid}\n")
    else:
        print("❌ Geen artikelen gevonden met de naam:", zoek_naam)

def update_voorraad(1):
    artikelen = laad_artikelen(1)
    if not artikelen:
        print("ℹ️ Geen artikelen gevonden.")
        return

    print("📋 Beschikbare artikelen:")
    for a in artikelen:
        print(f" - {a.naam} (ID: {a.id}) - Voorraad: {a.voorraad}")

    artikel_id = int(input("Voer de artikel ID in om de voorraad bij te werken: "))
    artikel = next((a for a in artikelen if a.id == artikel_id), None)

    if artikel:
        nieuwe_voorraad = int(input(f"Voer de nieuwe voorraad in voor {artikel.naam}: "))
        artikel.voorraad = nieuwe_voorraad
        opslaan_artikelen(artikelen)
        print("✅ Voorraad bijgewerkt.")
    else:
        print("❌ Artikel niet gevonden.")

def info(1):
    return "Artikelenbeheer-module actief – Magazijnartikelen en voorraadbeheer klaar"
