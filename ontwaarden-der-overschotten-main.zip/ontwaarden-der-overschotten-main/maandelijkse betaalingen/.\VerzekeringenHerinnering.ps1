# Laad het CSV-bestand met verzekeringsgegevens
$verzekeringen = Import-Csv -Path "C:\Verzekeringen\verzekeringen.csv"

# Stel een vervaldatum in om herinneringen te krijgen (bijvoorbeeld 30 dagen voor de vervaldatum)
$vervalDagen = 30

# Loop door elke verzekering
foreach ($verzekering in $verzekeringen) {
    $vervalDatum = [datetime]::Parse($verzekering.Vervaldatum)
    $dagenTotVervaldatum = ($vervalDatum - (Get-Date)).Days

    # Als de vervaldatum binnen het ingestelde aantal dagen ligt, stuur een herinnering
    if ($dagenTotVervaldatum -le $vervalDagen) {
        # Weergave in de console
        Write-Host "Herinnering: De verzekering voor $($verzekering.Naam) vervalt over $dagenTotVervaldatum dagen!"

        # Optioneel: Stuur een e-mail als je een e-mailaccount hebt ingesteld
        # Stel de e-mailinstellingen in
        $smtpServer = "smtp.jouwhost.com"      # Vervang door je SMTP-server
        $smtpFrom = "jouw-email@example.com"   # Vervang door je eigen e-mailadres
        $smtpTo = "ontvanger-email@example.com" # Vervang door het e-mailadres van de ontvanger
        $subject = "Verzekering Vervaldatum Herinnering"
        $body = "De verzekering voor $($verzekering.Naam) bij $($verzekering.Verzekeraar) vervalt op $($verzekering.Vervaldatum)."

        # Maak het e-mailbericht aan
        $mailmessage = New-Object system.net.mail.mailmessage
        $mailmessage.from = $smtpFrom
        $mailmessage.To.add($smtpTo)
        $mailmessage.Subject = $subject
        $mailmessage.Body = $body

        # Verstuur de e-mail
        $smtp = New-Object Net.Mail.SmtpClient($smtpServer)
        $smtp.Send($mailmessage)
    }
}
