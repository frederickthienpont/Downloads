SMTP-server: smtp.gmail.com

Poort: 587

E-mailadres: je eigen Gmail-adres (bijv. jouw-email@gmail.com)tten
