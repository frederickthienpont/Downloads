# main.py
from utils import lees_csv_pad, schrijf_csv_pad

ORIGINEEL_BESTAND = "data/klanten.csv"
FRAUDE_BESTAND = "data/fraudedata.csv"

def detecteer_fraude(orig_data, fraud_data):
    verschillen = []
    for origineel, fraud in zip(orig_data, fraud_data):
        verschil = origineel['balans'] - fraud['balans']
        if verschil != 0:
            verschillen.append({
                'klant_id': origineel['klant_id'],
                'segment': origineel['segment'],
                'verschil': verschil
            })
    return verschillen

def herstel_fraude(orig_data, fraud_data, verschillen):
    herstelde_data = fraud_data.copy()
    for verschil in verschillen:
        klant_id = verschil['klant_id']
        for klant in herstelde_data:
            if klant['klant_id'] == klant_id:
                klant['balans'] += verschil['verschil']
    return herstelde_data

def straf_fraudeur(fraud_data, verschillen):
    fraud_data_met_straf = fraud_data.copy()
    for verschil in verschillen:
        if verschil['verschil'] < 0:  # dader (heeft te veel)
            for klant in fraud_data_met_straf:
                if klant['klant_id'] == verschil['klant_id']:
                    print(f"⚠️ FRAUDEUR {klant['klant_id']} - wordt bestraft!")
                    klant['balans'] -= 10  # boete
    return fraud_data_met_straf

def main():
    orig_data = lees_csv_pad(ORIGINEEL_BESTAND)
    fraud_data = lees_csv_pad(FRAUDE_BESTAND)

    verschillen = detecteer_fraude(orig_data, fraud_data)

    if verschillen:
        print("🔍 Fraude gedetecteerd:")
        for v in verschillen:
            print(v)

        fraud_data = straf_fraudeur(fraud_data, verschillen)
        hersteld = herstel_fraude(orig_data, fraud_data, verschillen)

        schrijf_csv_pad("data/hersteld.csv", hersteld, headers=['klant_id', 'segment', 'balans'])
        print("\n✅ Herstel uitgevoerd. Data opgeslagen in: data/hersteld.csv")
    else:
        print("🎉 Geen fraude gevonden.")

if __name__ == "__main__":
    main()
