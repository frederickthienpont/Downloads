import os
import zipfile

project_files = {
    "fraudehersteltool/install_wizard.py": '''<PLAATS_HIER_DE_CODE_VAN_INSTALL_WIZARD>''',
    "fraudehersteltool/utils.py": '''<PLAATS_HIER_DE_CODE_VAN_UTILS>''',
    "fraudehersteltool/main.py": '''<PLAATS_HIER_DE_CODE_VAN_MAIN>'''
}

zip_filename = "fraudehersteltool.zip"

with zipfile.ZipFile(zip_filename, "w") as zipf:
    for filepath, content in project_files.items():
        zipf.writestr(filepath, content)

print(f"✅ ZIP-bestand aangemaakt: {zip_filename}")
