# install_wizard.py
import csv
import os

def run_install_wizard():
    print("👋 Welkom bij de Fraudeherstel Tool Installatiewizard")

    if not os.path.exists("data"):
        os.makedirs("data")

    klant_file = "data/klanten.csv"
    fraude_file = "data/fraudedata.csv"

    print("➡️  We maken voorbeeld klantgegevens aan...")
    with open(klant_file, mode='w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['klant_id', 'segment', 'balans'])  # headers
        writer.writerow(['1001', 'A', 100])
        writer.writerow(['1002', 'B', 200])
        writer.writerow(['1003', 'C', 300])

    print("➡️  We maken voorbeeld fraudedata aan...")
    with open(fraude_file, mode='w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['klant_id', 'segment', 'balans'])  # headers
        writer.writerow(['1001', 'A', 50])   # te weinig
        writer.writerow(['1002', 'B', 250])  # te veel
        writer.writerow(['1003', 'C', 300])  # goed

    print("✅ Installatie voltooid. Je kunt nu `main.py` uitvoeren.")
