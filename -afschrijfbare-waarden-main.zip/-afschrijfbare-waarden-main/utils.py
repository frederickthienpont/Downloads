# utils.py
import csv

def lees_csv_pad(pad):
    data = []
    with open(pad, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            row['balans'] = float(row['balans'])
            data.append(row)
    return data

def schrijf_csv_pad(pad, data, headers):
    with open(pad, mode='w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=headers)
        writer.writeheader()
        writer.writerows(data)
