from datetime import datetime, timedelta

class Vrachtschip:
    def __init__(self, naam, bemanning, artillerie, vracht):
        self.naam = naam
        self.bemanning = bemanning  # lijst van namen
        self.artillerie = artillerie  # lijst van wapens
        self.vracht = vracht  # lijst of beschrijving
        self.aangekomen = False
        self.aankomst_datum = None

class Verzekering:
    def __init__(self, schip, garantie_dagen):
        self.schip = schip
        self.start_datum = datetime.now()
        self.garantie_dagen = garantie_dagen
        self.vervallen = False

    def aankomst(self):
        self.schip.aangekomen = True
        self.schip.aankomst_datum = datetime.now()
        self.vervallen = True
        print(f"Verzekering vervallen op aankomst ({self.schip.aankomst_datum})")

    def status(self):
        if self.vervallen:
            return "Verzekering vervallen (schip aangekomen)"
        verschil = datetime.now() - self.start_datum
        if verschil.days >= self.garantie_dagen:
            self.vervallen = True
            return "Verzekering vervallen (tijd verstreken)"
        else:
            return f"Verzekering actief ({self.garantie_dagen - verschil.days} dagen resterend)"

    def details(self):
        return {
            "Schip": self.schip.naam,
            "Bemanning": self.schip.bemanning,
            "Artillerie": self.schip.artillerie,
            "Vracht": self.schip.vracht,
            "Garantie (dagen)": self.garantie_dagen,
            "Status": self.status()
        }

# Voorbeeldgebruik
schip = Vrachtschip(
    naam="Zeevlam",
    bemanning=["Kapitein Jan", "Matroos Piet"],
    artillerie=["Kanonnen", "Luchtafweer"],
    vracht="Militair materieel en medische voorraden"
)

verzekering = Verzekering(schip, garantie_dagen=30)

print("Initieel:", verzekering.details())

# Simuleer aankomst
verzekering.aankomst()

print("Na aankomst:", verzekering.details())
