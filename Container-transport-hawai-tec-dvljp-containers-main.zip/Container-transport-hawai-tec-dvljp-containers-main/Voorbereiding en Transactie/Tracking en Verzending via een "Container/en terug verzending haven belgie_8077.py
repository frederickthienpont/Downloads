# Simuleren van verzending en tracking van goederen
class Shipment:
    def __init__(self, item, sender, receiver, shipment_id):
        self.item = item
        self.sender = sender
        self.receiver = receiver
        self.shipment_id = shipment_id
        self.status = 'shipped'
        self.timestamp = time.time()

    def update_status(self, new_status):
        self.status = new_status
        self.timestamp = time.time()
        print(f"Verzendstatus bijgewerkt: {self.status}")

    def generate_report(self):
        # Afschriften genereren (PDF, tekstbestanden)
        report = f"Shipment Report: {self.shipment_id}\nItem: {self.item}\nSender: {self.sender}\nReceiver: {self.receiver}\nStatus: {self.status}\nTimestamp: {self.timestamp}"
        return report

# Voorbeeld van verzending
shipment = Shipment("Ferrari Grx-50", "HawaiiTec", "Marc vanB", "SH12345")
print(shipment.generate_report())

# Update de verzendstatus
shipment.update_status('delivered')
print(shipment.generate_report())
