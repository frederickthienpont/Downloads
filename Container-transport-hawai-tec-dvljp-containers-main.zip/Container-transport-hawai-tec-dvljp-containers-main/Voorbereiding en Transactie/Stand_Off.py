import bitcoin
import hashlib
import time

# Betalingstransactie in Bitcoin
def create_bitcoin_transaction(sender, receiver, amount, transaction_fee):
    transaction = {
        'sender': sender,
        'receiver': receiver,
        'amount': amount,
        'fee': transaction_fee,
        'timestamp': time.time(),
        'status': 'pending'
    }

    # Simuleren van een Bitcoin transactie
    transaction_hash = hashlib.sha256(str(transaction).encode()).hexdigest()
    transaction['transaction_hash'] = transaction_hash
    print(f"Transactie gecreëerd: {transaction}")
    return transaction

# Voorbeeld van een Bitcoin transactie
sender_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
receiver_address = "12cbQbbrhY6M7x6t5LJJm6Pmh2KJ1hfjFw"
amount = 0.002  # Bitcoin
transaction_fee = 0.0001  # Bitcoin

transaction = create_bitcoin_transaction(sender_address, receiver_address, amount, transaction_fee)
