import tkinter as tk
from modules import planning, transport, kosten, container

def open_module(name):
    if name == "Planning":
        planning.run()
    elif name == "Transport":
        transport.run()
    elif name == "Kosten":
        kosten.run()
    elif name == "Container":
        container.run()

app = tk.Tk()
app.title("SmartPort Logistics Manager")
app.geometry("400x300")

tk.Label(app, text="Selecteer een module:", font=("Arial", 14)).pack(pady=20)

buttons = [
    ("Planning", "Planning"),
    ("Transportbeheer", "Transport"),
    ("Transportkosten", "Kosten"),
    ("Containerbeheer", "Container")
]

for text, mod in buttons:
    tk.Button(app, text=text, command=lambda m=mod: open_module(m), width=25).pack(pady=5)

app.mainloop()
