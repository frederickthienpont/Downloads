import tkinter as tk
from tkinter import messagebox

def run():
    window = tk.Toplevel()
    window.title("Transportkosten Berekening")
    window.geometry("400x300")

    tk.Label(window, text="Afstand (km):").pack()
    km_entry = tk.Entry(window)
    km_entry.pack()

    tk.Label(window, text="Brandstofprijs per liter (€):").pack()
    prijs_entry = tk.Entry(window)
    prijs_entry.pack()

    def bereken():
        try:
            afstand = float(km_entry.get())
            prijs = float(prijs_entry.get())
            verbruik = 0.3  # liter per km
            totaal = afstand * verbruik * prijs
            messagebox.showinfo("Totale kost", f"Totale transportkost: €{totaal:.2f}")
        except:
            messagebox.showerror("Fout", "Ongeldige invoer")

    tk.Button(window, text="Bereken kost", command=bereken).pack(pady=20)
