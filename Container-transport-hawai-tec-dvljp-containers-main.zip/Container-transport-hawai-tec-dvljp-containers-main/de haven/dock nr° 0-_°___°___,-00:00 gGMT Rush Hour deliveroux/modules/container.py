import tkinter as tk
from tkinter import messagebox

def run():
    window = tk.Toplevel()
    window.title("Containerbeheer")
    window.geometry("400x300")

    tk.Label(window, text="Type lading (koel, chemisch, droog):").pack()
    lading = tk.Entry(window)
    lading.pack()

    def adviseer():
        l = lading.get().lower()
        if l == "koel":
            advies = "Gebruik gekoelde container (Reefer)"
        elif l == "chemisch":
            advies = "Gebruik ISO-tankcontainer"
        elif l == "droog":
            advies = "Gebruik standaard dry container"
        else:
            advies = "Gebruik speciale container"

        messagebox.showinfo("Advies", advies)

    tk.Button(window, text="Adviseer container", command=adviseer).pack(pady=20)
