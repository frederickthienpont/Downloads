import tkinter as tk
from tkinter import messagebox

def run():
    window = tk.Toplevel()
    window.title("Planning Module")
    window.geometry("400x300")

    tk.Label(window, text="Voer aankomsttijd in (hh:mm):").pack(pady=5)
    time_entry = tk.Entry(window)
    time_entry.pack(pady=5)

    def save():
        time = time_entry.get()
        messagebox.showinfo("Opgeslagen", f"Aankomsttijd gepland: {time}")

    tk.Button(window, text="Opslaan", command=save).pack(pady=20)
