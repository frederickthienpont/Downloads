import tkinter as tk
from tkinter import messagebox

def run():
    window = tk.Toplevel()
    window.title("Transportbeheer")
    window.geometry("400x300")

    tk.Label(window, text="Van punt A naar punt B").pack(pady=5)
    route = tk.Entry(window)
    route.pack(pady=5)

    tk.Label(window, text="Type vervoer (truck, boot, trein):").pack(pady=5)
    transport = tk.Entry(window)
    transport.pack(pady=5)

    def bereken():
        r = route.get()
        t = transport.get().lower()
        kosten = 0
        if t == "truck": kosten = 200
        elif t == "boot": kosten = 500
        elif t == "trein": kosten = 300
        else: kosten = 100

        messagebox.showinfo("Berekening", f"Route: {r}, Type: {t}, Kost: €{kosten}")

    tk.Button(window, text="Bereken transport", command=bereken).pack(pady=20)
