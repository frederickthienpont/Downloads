from flask import Flask, render_template, request
from datetime import datetime

app = Flask(__name__)

# Modelklassen
class Vrachtschip:
    def __init__(self, naam, bemanning, artillerie, vracht):
        self.naam = naam
        self.bemanning = bemanning
        self.artillerie = artillerie
        self.vracht = vracht
        self.aangekomen = False
        self.aankomst_datum = None

class Verzekering:
    def __init__(self, schip, garantie_dagen):
        self.schip = schip
        self.start_datum = datetime.now()
        self.garantie_dagen = garantie_dagen
        self.vervallen = False

    def aankomst(self):
        self.schip.aangekomen = True
        self.schip.aankomst_datum = datetime.now()
        self.vervallen = True

    def status(self):
        if self.vervallen:
            return "Verzekering vervallen (aangekomen)"
        verschil = datetime.now() - self.start_datum
        if verschil.days >= self.garantie_dagen:
            self.vervallen = True
            return "Verzekering vervallen (tijd verstreken)"
        else:
            return f"Actief ({self.garantie_dagen - verschil.days} dagen resterend)"

verzekering = None

@app.route("/", methods=["GET", "POST"])
def index():
    global verzekering
    message = ""
    if request.method == "POST":
        if 'maak' in request.form:
            schip = Vrachtschip(
                request.form["naam"],
                request.form["bemanning"].split(","),
                request.form["artillerie"].split(","),
                request.form["vracht"]
            )
            garantie = int(request.form["garantie_dagen"])
            verzekering = Verzekering(schip, garantie)
            message = "Verzekering aangemaakt."

        elif 'aankomst' in request.form and verzekering:
            verzekering.aankomst()
            message = "Aankomst geregistreerd. Verzekering vervallen."

    return render_template("index.html", verzekering=verzekering, message=message)

if __name__ == "__main__":
    app.run(debug=True)
