import tkinter as tk
from tkinter import messagebox
import os

selected_modules = []

def install_module(name):
    selected_modules.append(name)

def run_installation():
    with open("data/install_log.txt", "w") as log:
        for mod in selected_modules:
            log.write(f"Module geïnstalleerd: {mod}\n")
            __import__(f"modules.{mod}")
    messagebox.showinfo("Installatie", "Modules zijn succesvol geïnstalleerd en geladen.")
    root.quit()

root = tk.Tk()
root.title("Bissnes Talk Installer")
root.geometry("400x500")

tk.Label(root, text="Kies je Bissnes Modules:", font=("Arial", 16)).pack(pady=10)

mods = {
    "presentation": "📽️ Presentatie",
    "edex_lessons": "📘 Edex School Lessen",
    "nokel_quotes": "🧓 Wijsheden van Nokel Thienpont",
    "crypto_tool": "🪙 Crypto Real Flous Tool"
}

for key, label in mods.items():
    var = tk.IntVar()
    chk = tk.Checkbutton(root, text=label, variable=var, command=lambda k=key: install_module(k))
    chk.pack(anchor="w")

tk.Label(root, text="Kies je Extra Utilities:", font=("Arial", 14)).pack(pady=10)

utils = {
    "calculator": "🧮 Winstcalculator",
    "qr_generator": "📷 QR Generator",
    "text_editor": "📝 Teksteditor"
}

for key, label in utils.items():
    var = tk.IntVar()
    chk = tk.Checkbutton(root, text=label, variable=var, command=lambda k=key: install_module(f"../utils.{k}"))
    chk.pack(anchor="w")

tk.Button(root, text="Start Installatie", command=run_installation).pack(pady=20)
tk.Button(root, text="Annuleer", command=root.quit).pack()

root.mainloop()
