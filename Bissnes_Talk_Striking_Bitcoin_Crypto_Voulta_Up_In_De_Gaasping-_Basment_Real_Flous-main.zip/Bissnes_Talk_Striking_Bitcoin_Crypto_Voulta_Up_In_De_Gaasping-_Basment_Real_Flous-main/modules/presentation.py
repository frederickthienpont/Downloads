def run():
    print("Presentatie geladen... (in real-time GUI laden mogelijk)")
