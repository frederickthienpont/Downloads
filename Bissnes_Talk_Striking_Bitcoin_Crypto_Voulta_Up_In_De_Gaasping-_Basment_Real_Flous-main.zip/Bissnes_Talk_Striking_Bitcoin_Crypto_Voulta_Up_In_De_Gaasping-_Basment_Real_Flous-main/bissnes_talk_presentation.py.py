import tkinter as tk
from tkinter import messagebox

# Content van het boek/presentatie
slides = [
    {
        "title": "Bissnes Talk: Striking Bitcoin",
        "text": "Welkom in de Gaasping-Basement. Hier begon de Voulta-gedachte. Real Flous. Geen fabel, maar een plan."
    },
    {
        "title": "Crypto Voulta Protocol",
        "text": "Het Voulta Protocol groepeert waarde. Peer-to-peer, zonder verliespunten. Groepscode: 'THE PIMP'."
    },
    {
        "title": "Wijze Raad van Nokel Thienpont",
        "text": "\"Als ge’t niet kunt verkopen, moogt ge’t niet bouwen.\" Simpel. Zuiver. Tijdloos advies."
    },
    {
        "title": "De School van Edex",
        "text": "Hier leerden we structuren bouwen. Bitcoin analyseren. Winstpaden detecteren. Leren = investeren."
    },
    {
        "title": "Real Flous - Patentair Systeem",
        "text": "1. Identificeer lekken\n2. Bouw een Voulta-block\n3. Laat waarde groeien met groepsflows en crypto-injecties"
    },
    {
        "title": "Slot: Zaag of Bouwer?",
        "text": "Iedereen zaagt. Maar wie bouwt? Jij. Met deze presentatie. Met dit boek. Real Flous is gestart."
    }
]

class BissnesTalkApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Bissnes Talk – Real Flous")
        self.index = 0

        self.title_label = tk.Label(root, text="", font=("Arial", 20, "bold"), wraplength=600)
        self.title_label.pack(pady=10)

        self.text_label = tk.Label(root, text="", font=("Arial", 14), wraplength=600, justify="left")
        self.text_label.pack(pady=10)

        self.next_button = tk.Button(root, text="Volgende", command=self.next_slide)
        self.next_button.pack(pady=5)

        self.quit_button = tk.Button(root, text="Afsluiten", command=self.root.quit)
        self.quit_button.pack(pady=5)

        self.update_slide()

    def update_slide(self):
        slide = slides[self.index]
        self.title_label.config(text=slide["title"])
        self.text_label.config(text=slide["text"])

    def next_slide(self):
        self.index += 1
        if self.index < len(slides):
            self.update_slide()
        else:
            messagebox.showinfo("Einde", "Dit was het einde van Bissnes Talk: Real Flous.")
            self.root.quit()

# Run de app
if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("700x400")
    app = BissnesTalkApp(root)
    root.mainloop()
