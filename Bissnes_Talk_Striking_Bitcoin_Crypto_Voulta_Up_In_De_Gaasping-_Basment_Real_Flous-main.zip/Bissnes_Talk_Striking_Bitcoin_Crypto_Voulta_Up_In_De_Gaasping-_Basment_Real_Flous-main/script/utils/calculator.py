def winst_calculator(opbrengst, kosten):
    winst = opbrengst - kosten
    print(f"Totale winst: €{winst}")
    return winst
