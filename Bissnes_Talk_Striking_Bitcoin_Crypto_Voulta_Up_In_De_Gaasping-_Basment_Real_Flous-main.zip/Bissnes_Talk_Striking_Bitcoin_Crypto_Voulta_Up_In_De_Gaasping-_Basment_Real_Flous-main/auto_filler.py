files = {
    "bissnes_talk/installer.py": """# Installer code zoals eerder besproken""",
    "bissnes_talk/modules/presentation.py": """def run(): print("Presentatie geladen...")""",
    "bissnes_talk/utils/calculator.py": """def winst_calculator(o, k): return o - k""",
    "bissnes_talk/data/install_log.txt": """# Installatielog wordt hier opgeslagen"""
}

for path, content in files.items():
    with open(os.path.join(base_path, path), "w", encoding="utf-8") as f:
        f.write(content)
        print(f"Bestand aangemaakt: {path}")
