import os
import shutil
import sys

def mini_installer(bestand_pad, installatie_pad):
    try:
        # Controleer of het bestand bestaat
        if not os.path.exists(bestand_pad):
            print(f"Fout: Het bestand {bestand_pad} bestaat niet.")
            return

        # Maak de installatiepad aan als deze niet bestaat
        if not os.path.exists(installatie_pad):
            os.makedirs(installatie_pad)

        # Kopieer het bestand naar de installatiepad
        shutil.copy(bestand_pad, installatie_pad)
        print(f"Installatie voltooid! {bestand_pad} is gekopieerd naar {installatie_pad}")
    except Exception as e:
        print(f"Er is een fout opgetreden: {e}")

# Voorbeeld van het uitvoeren van de mini-installer
bestand_pad = "pad/naar/jouw/bestand.exe"  # Vervang dit met het werkelijke bestandspad
installatie_pad = "C:/Program Files/MijnApp"  # Vervang dit met het gewenste installatiepad

mini_installer(bestand_pad, installatie_pad)
