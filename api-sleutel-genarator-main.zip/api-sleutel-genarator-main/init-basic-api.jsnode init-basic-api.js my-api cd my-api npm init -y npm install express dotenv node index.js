const fs = require('fs');
const path = require('path');

const baseDir = process.argv[2] || 'basic-api';
fs.mkdirSync(baseDir, { recursive: true });

// index.js
fs.writeFileSync(path.join(baseDir, 'index.js'), `
require('dotenv').config();
const express = require('express');
const app = express();
const routes = require('./routes');
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use('/api', routes);

app.listen(PORT, () => console.log(\`API listening at http://localhost:\${PORT}\`));
`);

// routes.js
fs.writeFileSync(path.join(baseDir, 'routes.js'), `
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => res.send({ message: 'Hello API' }));

module.exports = router;
`);

// .env
fs.writeFileSync(path.join(baseDir, '.env'), `PORT=3000`);

console.log('✅ Basic API initialized in:', baseDir);
