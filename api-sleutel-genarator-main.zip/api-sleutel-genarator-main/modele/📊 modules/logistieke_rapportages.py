from datetime import datetime
from typing import List
import json
import os

BESTELLING_FILE = "data/bestellingen.json"
VOORRAAD_FILE = "data/voorraad.json"

class Bestelling:
    def __init__(self, id, leverancier_id, totaalbedrag, bestel_datum, verzend_datum=None):
        self.id = id
        self.leverancier_id = leverancier_id
        self.totaalbedrag = totaalbedrag
        self.bestel_datum = bestel_datum
        self.verzend_datum = verzend_datum

def laad_bestellingen() -> List[Bestelling]:
    if not os.path.exists(BESTELLING_FILE):
        return []
    with open(BESTELLING_FILE, "r") as f:
        data = json.load(f)
    return [Bestelling(**b) for b in data]

def logistiek_rapport(start_date: datetime, end_date: datetime):
    bestellingen = laad_bestellingen()
    aantal_ontvangen = 0
    aantal_verzonden = 0
    doorlooptijden = []

    for bestelling in bestellingen:
        if start_date <= bestelling.bestel_datum <= end_date:
            if bestelling.verzend_datum:
                aantal_verzonden += 1
                doorlooptijd = (bestelling.verzend_datum - bestelling.bestel_datum).days
                doorlooptijden.append(doorlooptijd)
            else:
                aantal_ontvangen += 1

    gemiddelde_doorlooptijd = sum(doorlooptijden) / len(doorlooptijden) if doorlooptijden else 0
    print(f"📦 Logistieke rapportage tussen {start_date.strftime('%Y-%m-%d')} en {end_date.strftime('%Y-%m-%d')}:")
    print(f"  Aantal ontvangen bestellingen: {aantal_ontvangen}")
    print(f"  Aantal verzonden bestellingen: {aantal_verzonden}")
    print(f"  Gemiddelde doorlooptijd van bestellingen (dagen): {gemiddelde_doorlooptijd:.2f}")

def info():
    return "Logistieke rapportage-module actief – Bewegingen van de voorraad en doorlooptijden bijhouden klaar"
