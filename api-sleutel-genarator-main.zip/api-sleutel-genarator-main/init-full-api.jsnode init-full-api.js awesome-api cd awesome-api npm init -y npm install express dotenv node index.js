const fs = require('fs');
const path = require('path');

const baseDir = process.argv[2] || 'full-api';
const dirs = ['controllers', 'routes', 'middleware', 'config'];

dirs.forEach(d => fs.mkdirSync(path.join(baseDir, d), { recursive: true }));

// index.js
fs.writeFileSync(path.join(baseDir, 'index.js'), `
require('dotenv').config();
const express = require('express');
const app = express();
const routes = require('./routes');
const { logger } = require('./middleware/logger');
const { notFound } = require('./middleware/errors');
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(logger);
app.use('/api', routes);
app.use(notFound);

app.listen(PORT, () => console.log(\`🚀 API listening on http://localhost:\${PORT}\`));
`);

// routes/index.js
fs.writeFileSync(path.join(baseDir, 'routes', 'index.js'), `
const express = require('express');
const router = express.Router();
const userRoutes = require('./users');

router.use('/users', userRoutes);

module.exports = router;
`);

// routes/users.js
fs.writeFileSync(path.join(baseDir, 'routes', 'users.js'), `
const express = require('express');
const router = express.Router();
const { getUsers } = require('../controllers/userController');

router.get('/', getUsers);

module.exports = router;
`);

// controllers/userController.js
fs.writeFileSync(path.join(baseDir, 'controllers', 'userController.js'), `
exports.getUsers = (req, res) => {
  res.json([{ id: 1, name: 'John Doe' }]);
};
`);

// middleware/logger.js
fs.writeFileSync(path.join(baseDir, 'middleware', 'logger.js'), `
exports.logger = (req, res, next) => {
  console.log(\`\${req.method} \${req.url}\`);
  next();
};
`);

// middleware/errors.js
fs.writeFileSync(path.join(baseDir, 'middleware', 'errors.js'), `
exports.notFound = (req, res) => {
  res.status(404).json({ error: 'Not Found' });
};
`);

// config/db.js (placeholder)
fs.writeFileSync(path.join(baseDir, 'config', 'db.js'), `// TODO: Add DB config`);

fs.writeFileSync(path.join(baseDir, '.env'), `PORT=3000`);
console.log('✅ Full API initialized in:', baseDir);
