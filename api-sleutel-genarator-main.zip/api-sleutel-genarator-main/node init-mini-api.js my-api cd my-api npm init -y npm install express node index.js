const fs = require('fs');
const path = require('path');

const baseDir = process.argv[2] || 'mini-api';

fs.mkdirSync(baseDir);
fs.writeFileSync(path.join(baseDir, 'index.js'), `
const express = require('express');
const app = express();
const PORT = 3000;

app.get('/', (req, res) => res.send('Hello from Mini API!'));

app.listen(PORT, () => console.log(\`Server running on http://localhost:\${PORT}\`));
`);

console.log('✅ Mini API initialized in:', baseDir);
