# Project: Autobot Beschermingssysteem

Dit project is een simulatie van een zelfdenkende, zelfverdedigende AI-Autobot met het MaximizeZaro-protocol.

## Inhoud
- `autobot.py`: Bevat de klasse voor de Autobot.
- `commondar_ai.py`: AI commandocentrum.
- `main.py`: Startpunt van de simulatie.

## Gebruik
1. Zorg dat je Python 3 hebt geïnstalleerd.
2. Open een terminal in de map en voer uit:
```bash
python main.py
