class CommOndarAI:
    def __init__(self):
        self.log = []
        self.autobots = []

    def registreer_autobot(self, autobot):
        self.autobots.append(autobot)
        self.log.append(f"{autobot.naam} geregistreerd.")
    
    def zend_commando(self, commando):
        print("🧠 AI Commando: " + commando)
        for autobot in self.autobots:
            print(f"➡️ {autobot.naam} ontvangt commando: {commando}")
