from autobot import AutoBot
from commondar_ai import CommOndarAI

# Instantieer Autobot en AI Commandocentrum
bumblezaro = AutoBot("BumbleZaro", beveiligingssleutel="omegaX2025")
commondar = CommOndarAI()

# Installatie
bumblezaro.installatie_wizard()
commondar.registreer_autobot(bumblezaro)

# Activeren
bumblezaro.activeer("omegaX2025")

# Speciale functies
bumblezaro.maximaliseer_zaro()
bumblezaro.zelf_repareren()
bumblezaro.bescherm_unicron_materie()

# Planeten verdedigen
planeten = ["Aarde", "Jupiter"]
bumblezaro.verdedig_planeten(planeten)

# Commando verzenden
commondar.zend_commando("Formatie Ruit Delta Alpha. Bescherm Zuidpoolportaal.")
