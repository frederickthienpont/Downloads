# Voeg een eenvoudige frontend toe met een Node.js Express server + HTML dashboard
frontend_path = os.path.join(base_path, "node_frontend")

os.makedirs(frontend_path, exist_ok=True)

# Schrijf server.js voor Express
server_js = """
const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.listen(PORT, () => {
    console.log(`Node frontend draait op http://localhost:${PORT}`);
});
"""

# index.html pagina voor de frontend
index_html = """
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Consultant Dashboard</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f4f4f4; }
        h1 { color: #333; }
        .box { background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="box">
        <h1>Welkom op het Dashboard</h1>
        <p>Deze Node.js frontend is gekoppeld aan de Python backend voor overheidsconsultants.</p>
        <p><a href="http://localhost:5000">Ga naar Python Backend</a></p>
    </div>
</body>
</html>
"""

# package.json voor Node.js frontend
frontend_package_json = """
{
  "name": "node-frontend",
  "version": "1.0.0",
  "description": "Frontend dashboard voor consultant tool",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "express": "^4.18.2"
  }
}
"""

# Bestanden aanmaken
with open(os.path.join(frontend_path, "server.js"), "w") as f:
    f.write(server_js.strip())

os.makedirs(os.path.join(frontend_path, "public"), exist_ok=True)
with open(os.path.join(frontend_path, "public/index.html"), "w") as f:
    f.write(index_html.strip())

with open(os.path.join(frontend_path, "package.json"), "w") as f:
    f.write(frontend_package_json.strip())

# ZIP opnieuw aanmaken met frontend
zip_path_frontend = f"/mnt/data/{project_name}_with_node_frontend.zip"
with zipfile.ZipFile(zip_path_frontend, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for foldername, subfolders, filenames in os.walk(base_path):
        for filename in filenames:
            filepath = os.path.join(foldername, filename)
            zipf.write(filepath, os.path.relpath(filepath, base_path))

zip_path_frontend
