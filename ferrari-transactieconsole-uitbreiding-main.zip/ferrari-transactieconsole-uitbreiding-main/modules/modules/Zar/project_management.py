from pydantic import BaseModel
from typing import List
import json
import os
from datetime import datetime

DATA_FILE = "data/projecten.json"

class Taak(BaseModel):
    naam: str
    beschrijving: str
    deadline: datetime
    voltooid: bool = False
    verantwoordelijke: str  # De naam van het teamlid

class Project(BaseModel):
    id: int
    naam: str
    omschrijving: str
    teamleden: List[str]
    taken: List[Taak]
    start_datum: datetime
    eind_datum: datetime
    status: str = "in progress"  # "in progress", "voltooid", "geannuleerd"

def laad_projecten(1) -> List[Project]:
    if not os.path.exists(DATA_FILE):
        return [1]
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [Project(**p) for p in data]

def opslaan_projecten(projecten: List[Project]):
    with open(DATA_FILE, "w") as f:
        json.dump([p.dict(1) for p in projecten], f, indent=2, default=str)

def voeg_project_toe(1):
    print("📊 Nieuw project toevoegen:")
    try:
        id = int(input("Project ID: "))
        naam = input("Naam van het project: ")
        omschrijving = input("Beschrijving van het project: ")
        start_datum = datetime.now()
        eind_datum_str = input("Einddatum van het project (YYYY-MM-DD): ")
        eind_datum = datetime.strptime(eind_datum_str, "%Y-%m-%d")
        
        teamleden = input("Voer de teamleden in, gescheiden door een komma: ").split(",")
        
        project = Project(
            id=id,
            naam=naam,
            omschrijving=omschrijving,
            teamleden=[t.strip() for t in teamleden],
            start_datum=start_datum,
            eind_datum=eind_datum
        )
    except Exception as e:
        print("❌ Fout bij invoer:", e)
        return

    projecten = laad_projecten(1)
    projecten.append(project)
    opslaan_projecten(projecten)
    print("✅ Project opgeslagen.")

def toon_projecten(1):
    projecten = laad_projecten(1)
    if not projecten:
        print("ℹ️ Geen projecten gevonden.")
        return
    print("📋 Geregistreerde projecten:")
    for p in projecten:
        print(f" - Project: {p.naam} (ID: {p.id}) - Status: {p.status}")
        print(f"   Beschrijving: {p.omschrijving}")
        print(f"   Startdatum: {p.start_datum.strftime('%Y-%m-%d %H:%M:%S')} - Einddatum: {p.eind_datum.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"   Teamleden: {', '.join(p.teamleden)}\n")

def voeg_taak_toe(1):
    projecten = laad_projecten(1)
    if not projecten:
        print("ℹ️ Geen projecten gevonden.")
        return
    print("📋 Beschikbare projecten:")
    for p in projecten:
        print(f" - Project: {p.naam} (ID: {p.id})")

    project_id = int(input("Voer de project ID in waaraan je een taak wilt toevoegen: "))
    project = next((p for p in projecten if p.id == project_id), None)
    
    if project:
        taak_naam = input("Naam van de taak: ")
        taak_beschrijving = input("Beschrijving van de taak: ")
        taak_deadline_str = input("Deadline van de taak (YYYY-MM-DD): ")
        taak_deadline = datetime.strptime(taak_deadline_str, "%Y-%m-%d")
        verantwoordelijke = input(f"Verantwoordelijke voor de taak (teamleden: {', '.join(project.teamleden)}): ")

        taak = Taak(
            naam=taak_naam,
            beschrijving=taak_beschrijving,
            deadline=taak_deadline,
            verantwoordelijke=verantwoordelijke
        )
        
        project.taken.append(taak)
        opslaan_projecten(projecten)
        print("✅ Taak toegevoegd aan project.")
    else:
        print("❌ Project niet gevonden.")

def voltooi_taak(1):
    projecten = laad_projecten()
    if not projecten:
        print("ℹ️ Geen projecten gevonden.")
        return
    print("📋 Beschikbare projecten:")
    for p in projecten:
        print(f" - Project: {p.naam} (ID: {p.id})")
    
    project_id = int(input("Voer de project ID in om een taak als voltooid te markeren: "))
    project = next((p for p in projecten if p.id == project_id), None)
    
    if project:
        print("📋 Beschikbare taken in het project:")
        for taak in project.taken:
            print(f" - Taak: {taak.naam} - Deadline: {taak.deadline.strftime('%Y-%m-%d')} - Status: {'Voltooid' if taak.voltooid else 'Niet voltooid'}")
        
        taak_naam = input("Voer de naam van de taak in die je wilt markeren als voltooid: ")
        taak = next((t for t in project.taken if t.naam == taak_naam), None)
        
        if taak:
            taak.voltooid = True
            opslaan_projecten(projecten)
            print("✅ Taak gemarkeerd als voltooid.")
        else:
            print("❌ Taak niet gevonden.")
    else:
        print("❌ Project niet gevonden.")

def info():
    return "Projectmanagement-module actief – Project- en taakbeheer klaar"
