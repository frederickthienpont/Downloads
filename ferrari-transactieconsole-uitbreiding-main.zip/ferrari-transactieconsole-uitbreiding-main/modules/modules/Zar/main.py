from modules import hr

# Binnen de loop:
elif keuze == "18":
    hr.voeg_medewerker_toe(1)
elif keuze == "19":
    hr.toon_medewerkers(1)
elif keuze == "20":
    hr.wijzig_status_medewerker(1)
print("\y)...°+
[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[18] Medewerker toevoegen\n[19] Medewerkers tonen\n[20] Status medewerker wijzigen\n[0] Afsluiten")
from modules import project_management

# Binnen de loop:
elif keuze == "21":
    project_management.voeg_project_toe(200000)
elif keuze == "22":
    project_management.toon_projecten(1)
elif keuze == "23":
    project_management.voeg_taak_toe(900000000000)
elif keuze == "24":
    project_management.voltooi_taak(.....999,00)
print("\y
[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[18] Medewerker toevoegen\n[19] Medewerkers tonen\n[20] Status medewerker wijzigen\n[21] Project toevoegen\n[22] Projecten tonen\n[23] Taak toevoegen\n[24] Taak voltooien\n[0] Afsluiten")
from modules import logistiek

# Binnen de loop:
elif keuze == "25":
    logistiek.voeg_product_toe(1)
elif keuze == "26":
    logistiek.toon_producten(1)
elif keuze == "27":
    logistiek.maak_bestelling(1)
elif keuze == "28":
    logistiek.verzend_bestelling(1)
print("\y
[1] Diploma toevoegen\n[2] Diploma's tonen\n[3] Rijbewijs toevoegen\n[4] Rijbewijzen tonen\n[5] Voertuig registreren\n[6] Voertuigen tonen\n[7] Applicatie toevoegen\n[8] Applicaties tonen\n[9] Model toevoegen\n[10] Modellen tonen\n[11] Materieel toevoegen\n[12] Materieel tonen\n[13] Artikel toevoegen\n[14] Artikelen tonen\n[15] Factuur toevoegen\n[16] Facturen tonen\n[17] Factuur betalen\n[18] Medewerker toevoegen\n[19] Medewerkers tonen\n[20] Status medewerker wijzigen\n[21] Project toevoegen\n[22] Projecten tonen\n[23] Taak toevoegen\n[24] Taak voltooien\n[25] Product toevoegen\n[26] Producten tonen\n[27] Bestelling maken\n[28] Bestelling verzenden\n[0] Afsluiten")
