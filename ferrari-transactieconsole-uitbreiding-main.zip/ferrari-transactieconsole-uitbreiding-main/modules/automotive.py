from pydantic import BaseModel, Field, validator
from datetime import date, datetime
from typing import List
import json
import os

DATA_FILE = "data/voertuigen.json"

class Voertuig(BaseModel):
    eigenaar: str
    kenteken: str = Field(..., regex=r"^[A-Z0-9-]{6,8}$")
    merk: str
    model: str
    bouwjaar: int = Field(..., ge=1950, le=date.today().year)
    apk_vervaldatum: date

    @validator("apk_vervaldatum")
    def check_apk_future(cls, v):
        if v < date.today():
            raise ValueError("APK-vervaldatum mag niet in het verleden liggen.")
        return v

def laad_voertuigen() -> List[Voertuig]:
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        data = json.load(f)
    return [Voertuig(**v) for v in data]

def opslaan_voertuigen(voertuigen: List[Voertuig]):
    with open(DATA_FILE, "w") as f:
        json.dump([v.dict() for v in voertuigen], f, indent=2, default=str)

def voeg_voertuig_toe():
    print("🚗 Nieuw voertuig registreren:")
    try:
        eigenaar = input("Naam eigenaar: ")
        kenteken = input("Kenteken (bijv. AB-123-CD): ").upper()
        merk = input("Merk: ")
        model = input("Model: ")
        bouwjaar = int(input("Bouwjaar: "))
        apk = input("APK-vervaldatum (YYYY-MM-DD): ")
        voertuig = Voertuig(
            eigenaar=eigenaar,
            kenteken=kenteken,
            merk=merk,
            model=model,
            bouwjaar=bouwjaar,
            apk_vervaldatum=datetime.strptime(apk, "%Y-%m-%d").date()
        )
    except Exception as e:
        print("❌ Fout bij invoer:", e)
        return

    voertuigen = laad_voertuigen()
    voertuigen.append(voertuig)
    opslaan_voertuigen(voertuigen)
    print("✅ Voertuig opgeslagen.")

def toon_voertuigen():
    voertuigen = laad_voertuigen()
    if not voertuigen:
        print("ℹ️ Geen voertuigen gevonden.")
        return
    print("📋 Geregistreerde voertuigen:")
    for v in voertuigen:
        print(f" - {v.kenteken}: {v.merk} {v.model} ({v.bouwjaar}), APK tot {v.apk_vervaldatum}, eigenaar: {v.eigenaar}")

def info():
    return "Automotive-module actief – voertuigenbeheer operationeel"
