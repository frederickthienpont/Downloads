# install_wizard.py
import os
from modules.controller import RaibanstripController
from modules.finance_ai import FinancialAICore

def run_installation():
    print("🚗 Ferrari Transactie Console Installatie gestart...")
    os.makedirs("logs", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    print("✅ Mappenstructuur aangemaakt.")
    
    controller = RaibanstripController()
    controller.initialize_device()

    ai_core = FinancialAICore()
    ai_core.load_compressed_model("models/compressed_model.ai")

    print("✅ Installatie voltooid. Console is klaar voor gebruik.")

if __name__ == "__main__":
    run_installation()
