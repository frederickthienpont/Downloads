# install_wizard.py
import os
from modules.controller import RaibanstripController
from modules.finance_ai import FinancialAICore
import time

def run_installation():
    print("🚗 Ferrari Transactie Console Installatie gestart...")

    # Stap 1: Controleer en maak de benodigde mappen aan
    os.makedirs("logs", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    print("✅ Mappenstructuur aangemaakt.")
    
    # Stap 2: Initialiseer de RaibanstripController
    controller = RaibanstripController()
    controller.initialize_device()

    # Stap 3: Laad het financiële AI-model
    ai_core = FinancialAICore()
    ai_core.load_compressed_model("models/compressed_model.ai")
    
    # Stap 4: Voer een testtransactie uit
    card_data = controller.read_card()
    if controller.validate_card(card_data):
        print("💳 Kaart gevalideerd, klaar voor transactie.")
        
        # Testbedrag
        amount = 100.0  # Stel een testbedrag in voor de transactie
        
        # Verwerk de transactie via de AI
        if ai_core.process_transaction(card_data, amount):
            print("✅ Transactie goedgekeurd.")
        else:
            print("⛔ Transactie geweigerd.")
    else:
        print("❌ Fout bij kaartvalidatie.")
    
    # Installatie voltooid
    print("✅ Installatie voltooid. Console is klaar voor gebruik.")
    print("📅 Logbestanden opgeslagen in de logs-directory.")

if __name__ == "__main__":
    run_installation()
