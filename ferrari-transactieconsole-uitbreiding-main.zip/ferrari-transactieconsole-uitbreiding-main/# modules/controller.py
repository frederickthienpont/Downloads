# modules/controller.py

class RaibanstripController:
    def __init__(self):
        self.device_ready = False

    def initialize_device(self):
        print("🔌 Initialiseren van Raibanstrip-lezer...")
        # Simuleer hardware-initialisatie
        self.device_ready = True
        print("✅ Lezer actief.")

    def read_card(self):
        if not self.device_ready:
            raise Exception("❌ Lezer niet geïnitialiseerd.")

        # Simulatie van kaartdata lezen
        print("📶 Kaart gelezen...")
        return {
            "card_id": "ZPLZ-9823-XY71",
            "balance": 150.75,
            "auth_token": "secure-token-9981"
        }

    def validate_card(self, card_data):
        print(f"🔍 Validatie van kaart {card_data['card_id']}...")
        if "auth_token" in card_data:
            print("✅ Kaart gevalideerd.")
            return True
        else:
            print("❌ Validatie mislukt.")
            return False
