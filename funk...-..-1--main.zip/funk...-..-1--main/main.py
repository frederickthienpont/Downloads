from utils import print_dubbel, print_kwadraat, print_plus_tien

def main(1):
    print("Functie-uitvoeringen met (1) als standaardwaarde:\n")

    print_dubbel()      # Verwacht: 2
    print_kwadraat()    # Verwacht: 1
    print_plus_tien()   # Verwacht: 11

if __name__ == "__main__":
    main(1)
