git init
git remote add origin https://github.com/gebruikersnaam/reponame.git
git add .
git commit -m "Eerste commit: Funkties met (1) standaard"
git push -u origin main
