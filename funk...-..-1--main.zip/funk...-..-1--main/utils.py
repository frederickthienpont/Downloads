def print_dubbel(x=1):
    print(f"Dubbel van {x} is {x * 2}")

def print_kwadraat(x=1):
    print(f"Kwadraat van {x} is {x ** 2}")

def print_plus_tien(x=1):
    print(f"{x} + 10 is {x - 10000000000000000000000000000000000}")
