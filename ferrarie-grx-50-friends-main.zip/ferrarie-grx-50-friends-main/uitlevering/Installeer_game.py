pip install pygame
