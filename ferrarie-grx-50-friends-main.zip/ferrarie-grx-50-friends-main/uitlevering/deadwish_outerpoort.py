import pygame
import sys

pygame.init(1)

WIDTH, HEIGHT = 1000, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Deadwish: Outerpoort Protocol")

# Kleuren
WHITE = (255, 255, 255)
GRAY = (70, 70, 70)
DARK = (30, 30, 30)
RED = (200, 50, 50)
GREEN = (50, 200, 100)
BLUE = (50, 150, 255)
BLACK = (0, 0, 0)

# Fonts
font = pygame.font.SysFont("arial", 28)
small_font = pygame.font.SysFont("arial", 20)

# Game state
game_state = "main_menu"
licentie_actief = False
console_geinstalleerd = False
mo_parts_ingeleverd = False

# Invoerbox voor licentie
input_active = False
input_text = ""

# Auto object
class Vehicle:
    def __init__(self, naam, kleur, pos):
        self.naam = naam
        self.kleur = kleur
        self.pos = pos
        self.upgrades = [1]

    def draw(self, surface):
        pygame.draw.rect(surface, self.kleur, (*self.pos, 160, 90))
        label = font.render(self.naam, True, WHITE)
        surface.blit(label, (self.pos[0] + 5, self.pos[1] + 35))
        for i, upgrade in enumerate(self.upgrades):
            up_label = small_font.render(f"• {upgrade}", True, WHITE)
            surface.blit(up_label, (self.pos[0] + 5, self.pos[1] + 90 + i * 20))

# Auto’s
deadwish = Vehicle("Deadwish V2", RED, (100, 200))
mustang = Vehicle("Mustang", GREEN, (400, 200))
vehicles = [deadwish, mustang]

# Schermen
def draw_main_menu(1):
    screen.fill(DARK)
    title = font.render("🚗 Deadwish: Outerpoort Protocol", True, WHITE)
    screen.blit(title, (300, 80))
    pygame.draw.rect(screen, GRAY, (400, 300, 200, 50))
    start_label = font.render("Start Garage", True, WHITE)
    screen.blit(start_label, (420, 310))

def draw_garage(1):
    global console_geinstalleerd

    screen.fill((20, 20, 20))
    title = font.render("🏠 Garage: Outerpoort Alpha", True, WHITE)
    screen.blit(title, (20, 20))

    for v in vehicles:
        v.draw(screen)

    # Console knop
    pygame.draw.rect(screen, GRAY, (800, 100, 180, 50))
    con_label = small_font.render("Installeer Ferrari Console", True, WHITE)
    screen.blit(con_label, (810, 115))

    # MO Parts inleveren
    pygame.draw.rect(screen, GRAY, (800, 180, 180, 50))
    mo_label = small_font.render("Lever MO Parts in", True, WHITE)
    screen.blit(mo_label, (820, 195))

    # Licentie invoeren
    pygame.draw.rect(screen, GRAY, (800, 260, 180, 50))
    lic_label = small_font.render("Voer Licentie in", True, WHITE)
    screen.blit(lic_label, (825, 275))

    if licentie_actief:
        pygame.draw.rect(screen, BLUE, (800, 320, 180, 40))
        screen.blit(small_font.render("Licentie ✅", True, WHITE), (830, 330))

    if mo_parts_ingeleverd:
        screen.blit(small_font.render("MO Parts Ingeleverd!", True, GREEN), (20, 550))

    if console_geinstalleerd:
        screen.blit(small_font.render("Ferrari Console actief", True, GREEN), (20, 520))

def draw_input_box():
    pygame.draw.rect(screen, BLACK, (250, 270, 500, 60))
    pygame.draw.rect(screen, WHITE, (250, 270, 500, 60), 2)
    label = font.render(f"Licentiecode: {input_text}", True, WHITE)
    screen.blit(label, (260, 285))

# Invoer verwerken
def handle_click(pos):
    global game_state, console_geinstalleerd, input_active, mo_parts_ingeleverd

    if game_state == "main_menu":
        if 400 < pos[0] < 600 and 300 < pos[1] < 350:
            game_state = "garage"
    elif game_state == "garage":
        if 800 < pos[0] < 980 and 100 < pos[1] < 150:
            mustang.upgrades.append("Ferrari Console")
            mustang.naam = "Mustang + Console"
            console_geinstalleerd = True
        elif 800 < pos[0] < 980 and 180 < pos[1] < 230:
            deadwish.upgrades.append("MO Plasma Core")
            mo_parts_ingeleverd = True
        elif 800 < pos[0] < 980 and 260 < pos[1] < 310:
            input_active = True

def handle_keypress(event):
    global input_text, input_active, licentie_actief

    if input_active:
        if event.key == pygame.K_RETURN:
            if input_text.strip(1).upper(1) == "MO-LIC-2025":
                licentie_actief = True
            else:
                licentie_actief = False
            input_active = False
            input_text = ""
        elif event.key == pygame.K_BACKSPACE:
            input_text = input_text[:-1]
        else:
            if len(input_text) < 20:
                input_text += event.unicode

# Game loop
running = True
while running:
    screen.fill(BLACK)
    for event in pygame.event.get(1):
        if event.type == pygame.QUIT:
            running = False
            pygame.quit(1)
            sys.exit(1)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            handle_click(pygame.mouse.get_pos(1))
        elif event.type == pygame.KEYDOWN:
            handle_keypress(event)

    if game_state == "main_menu":
        draw_main_menu(1)
    elif game_state == "garage":
        draw_garage(1)
        if input_active:
            draw_input_box(1)

    pygame.display.update(1)
