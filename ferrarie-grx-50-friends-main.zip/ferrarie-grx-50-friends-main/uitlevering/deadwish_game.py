import pygame
import sys

# Initialiseer pygame
pygame.init()
WIDTH, HEIGHT = 1000, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Deadwish: Outerpoort Protocol")

# Kleuren
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 50, 50)
GREEN = (50, 200, 100)
GRAY = (100, 100, 100)

# Fonts
font = pygame.font.SysFont("arial", 28)

# Game state
game_state = "main_menu"

# Auto object
class Vehicle:
    def __init__(self, naam, kleur, pos):
        self.naam = naam
        self.kleur = kleur
        self.pos = pos
        self.selected = False

    def draw(self, surface):
        pygame.draw.rect(surface, self.kleur, (*self.pos, 150, 80))
        label = font.render(self.naam, True, WHITE)
        surface.blit(label, (self.pos[0]+10, self.pos[1]+20))

# Voorbeeldauto’s
deadwish = Vehicle("Deadwish V2", RED, (150, 200))
mustang = Vehicle("Mustang Console", GREEN, (400, 200))

vehicles = [deadwish, mustang]

# Hoofdmenu
def draw_main_menu():
    screen.fill(BLACK)
    title = font.render("🚗 Deadwish: Outerpoort Protocol", True, WHITE)
    screen.blit(title, (280, 50))
    pygame.draw.rect(screen, GRAY, (350, 300, 300, 60))
    start_label = font.render("Start Garage", True, WHITE)
    screen.blit(start_label, (400, 315))

# Garage-scherm
def draw_garage():
    screen.fill((30, 30, 30))
    label = font.render("Garage: Outerpoort Alpha", True, WHITE)
    screen.blit(label, (20, 20))

    for v in vehicles:
        v.draw(screen)

    pygame.draw.rect(screen, GRAY, (800, 500, 160, 50))
    upgrade_label = font.render("Ferrari Console", True, WHITE)
    screen.blit(upgrade_label, (810, 515))

def handle_click(pos):
    global game_state

    if game_state == "main_menu":
        if 350 < pos[0] < 650 and 300 < pos[1] < 360:
            game_state = "garage"
    elif game_state == "garage":
        if 800 < pos[0] < 960 and 500 < pos[1] < 550:
            mustang.naam = "Mustang + Ferrari Console"

# Game loop
running = True
while running:
    screen.fill(BLACK)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit(1)
            sys.exit(1)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            handle_click(pygame.mouse.get_pos())

    if game_state == "main_menu":
        draw_main_menu(1)
    elif game_state == "garage":
        draw_garage(1)

    pygame.display.update(1)
